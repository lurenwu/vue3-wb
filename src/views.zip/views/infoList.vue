

<template>
  <div class="seting-box">
    <s-header :name="'信息列表'"   icon-right="icon-sousuo_o" @right-callback="handleGoRouter('search')"></s-header>
    <div class="brand-container">
      <div class="tab" v-if="self_brand_code !== brand_code || self_brand_code === ''">
        <div class="tab-item" :class="{'active':curTab === item.value}" v-for="(item, index) in tabList" :key="index" @click="toggleTab(item.value)">{{item.title}}</div>
      </div>
      <div class="info-box" v-for="(item, index) in infoList" :key="index" @click="handleGoRouter((self_brand_code !== brand_code ? 'info':'publish'),{id:item.id})">
        <div class="info-item">
           <div class="item">
            <div class="title">{{item.address}}</div>
            <div>{{item.status === 0 ? '未跟进' : '跟进中'}}</div>
          </div>
          <div class="item">
            <div></div>
            <div>{{item.nature === 0 ? '未读' : '已读'}}</div>
          </div>
          <div class="item">
            <div>{{item.nature === 0 ? '毛坯' : '二改房'}}</div>
            <div>{{item.create_time}}</div>
          </div>
        </div>
      </div>
    </div>
  
  </div>
</template>

<script>
import { reactive, onMounted, toRefs } from 'vue'
import sHeader from '@/components/SimpleHeader'
import { getInfoList } from '@/service/index'
import { useRoute, useRouter } from 'vue-router'
import { getLocal } from '@/common/js/utils'

export default {
  components: {
    sHeader
  },
  setup() {
    const route = useRoute()
    const router = useRouter()
    const state = reactive({
      from: route.query.from,
      brand_code:"",
      self_brand_code:"",
      curTab: '',
      infoList:[],
      tabList:[
        {
          title: '全部',
          value: ''
        },
        {
          title: '跟进中',
          value: 0
        },
        {
          title: '未跟进',
          value: 1
        },
        {
          title: '未读',
          value: 2
        },
        {
          title: '已读',
          value: 3
        }
      ]
    })

    onMounted(async () => {
      const { brand_code } = route.query;
      state.brand_code = brand_code;
      state.self_brand_code = getLocal("brand_code");
      state.infoList = [
        {
          id:1,
          address: "1231231313dasdasdasdads",
          status:0,
          isread:0,
          nature:0,
          create_time:"2020/03/10"
        },
        {
          id:2,
          address: "1231231313dasdasdasdads",
          status:0,
          isread:0,
          nature:1,
          create_time:"2020/03/10"
        }
      ]
      handleGetInfoList();
    })
    const toggleTab = (tab)=>{
      state.curTab = tab;
      handleGetInfoList()
    }
    const handleGetInfoList = async () => {
      var params = {
        status:  state.curTab === 0 ? 0 : state.curTab === 1 ? 1 : '',
        isread: state.curTab === 2 ? 0 : state.curTab === 3 ? 1 : '',
        brand_code: state.brand_code,
        self_brand_code: state.self_brand_code
      }
      getInfoList(params).then((data)=>{
        var response = data.data;
        state.infoList = response.list;
      });
    };
    const handleGoRouter = async (path,query) => {
      router.push({ path: path, query: query})
    }
    
    return {
      ...toRefs(state),
      toggleTab,
      handleGoRouter,
      handleGetInfoList
    }
  }
}
</script>

<style lang="less" scoped>
  @import '../common/style/mixin';
  .brand-container {
    padding: 10px 20px;
    .info-box {
      margin-bottom: 20px;
      width: 100%;
      height: 100px;
      box-shadow: 1px 3px 10px 5px #eeeaea;
      border-radius: 5px;

      .info-item {
        padding: 10px 15px;
      }
      .item {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #cfcfcf;
        align-items: center;
        padding-bottom: 10px;
        .title {
          font-weight: 500;
          color: #000;
          font-size: 16px
        }
      }
    }
    .tab {
      .fj();
      margin-bottom: 15px;
      .tab-item {
        text-align: center;
        border: 1px solid #b8b8b8;
        width: 60px;
        height: 30px;
        line-height: 30px;
        border-radius: 5px;
        color: #b8b8b8;
        &.active {
          color: #fff;
          border: 0;
          background: #cc322c;
        }
      }
    }
  }
</style>
