

import axios from '../utils/axios'

export function login(params) {
  return axios({
    url: '/Auth.ashx?t=login',
    method: 'post',
    params
  })
}


export function updateKehuInfoStatus(params) {
  return axios({
    url: '/Auth.ashx?t=updateKehuInfoStatus',
    method: 'post',
    params
  })
}


export function getInfo(params) {
  return axios({
    url: '/Auth.ashx?t=getInfo',
    method: 'get',
    params
  })
}
export function addInfo(params) {
  return axios({
    url: '/Auth.ashx?t=addInfo',
    method: 'post',
    params
  })
}
export function editInfo(params) {
  return axios({
    url: '/Auth.ashx?t=editInfo',
    method: 'post',
    params
  })
}


export function getInfoList(params) {
  return axios({
    url: '/Auth.ashx?t=getInfoList',
    method: 'get',
    params
  })
}



export function getBrandList(params) {
  return axios({
    url: '/Auth.ashx?t=getBrandList',
    method: 'get',
    params
  })
}

export function get(params) {
  return axios({
    url: '/Auth.ashx',
    method: 'get',
    params
  })
}

export function post(params) {
 
  return axios({
    url: '/Auth.ashx',
    method: 'post',
    params
  })
}

