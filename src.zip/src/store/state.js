

export default {
  cartCount: 0
}
