

import axios from '../utils/axios'

export function login(data) {
  return axios({
    url: '/Auth.ashx?t=login',
    method: 'post',
    data
  })
}


export function updateKehuInfoStatus(data) {
  return axios({
    url: '/Auth.ashx?t=updateKehuInfoStatus',
    method: 'post',
    data
  })
}


export function getInfo(params) {
  return axios({
    url: '/Auth.ashx?t=getInfo',
    method: 'get',
    params
  })
}
export function addInfo(data) {
  return axios({
    url: '/Auth.ashx?t=addInfo',
    method: 'post',
    data
  })
}
export function editInfo(data) {
  return axios({
    url: '/Auth.ashx?t=editInfo',
    method: 'post',
    data
  })
}


export function getInfoList(params) {
  return axios({
    url: '/Auth.ashx?t=getInfoList',
    method: 'get',
    params
  })
}



export function getBrandList(params) {
  return axios({
    url: '/Auth.ashx?t=getBrandList',
    method: 'get',
    params
  })
}

export function get(params) {
  return axios({
    url: '/Auth.ashx',
    method: 'get',
    params
  })
}

export function post(data) {
  console.log(data)
  return axios({
    url: '/Auth.ashx',
    method: 'post',
    data
  })
}

